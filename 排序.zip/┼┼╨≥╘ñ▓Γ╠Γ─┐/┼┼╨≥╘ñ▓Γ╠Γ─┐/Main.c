#include <stdio.h>
#include <stdlib.h>
void XuanZe(int a[6]);
void ChaRu(int a[6]);
void MaoPao(int a[6]);
int main(){
	int sel=1,a[6],i;
	printf("===========����===========\n");
	printf("1.ѡ������\n");
	printf("2.��������\n");
	printf("3.ð������\n");
	
	 
		printf("�������ţ�");
		scanf("%d",&sel);
		printf("����������������");
		for(i=0;i<6;i++)
		scanf("%d",&a[i]);
		switch(sel){
		case 1:{
			   XuanZe(a);break;
			   }
		case 2:{
			   ChaRu(a);break;
			   }
		case 3:{
			   MaoPao(a);break;
			   }
		case 0:{
			   printf("�˳�\n");break;
			   }  
		}
		system("pause");
    return 0;
}
void XuanZe(int a[6]){
	
	int n,i,j,min,t;
	 
	 n=6;
	for(i=0;i<n-1;i++){
		min=i;
		for(j=i+1;j<n;j++){
			if(a[j]<a[min]){
				min=j;
			}
		}
		t=a[min];
		a[min]=a[i];
		a[i]=t;
	}
	for(i=0;i<n;i++){
	   printf("%d  ",a[i]);
	}
	printf("\n");
}
void ChaRu(int a[6]){
	
	int n,i,j,min,t;
	 n=6;
	 
	for(i=1;i<n;i++){
		t=a[i];
		for(j=i-1;j>=0;j--){
			if(a[j]>t){
				a[j+1]=a[j];
			}
			else{
			break;
			}
		}
		
		a[j+1]=t;
	}
	for(i=0;i<n;i++){
	   printf("%d  ",a[i]);
	}
	printf("\n");
}
void MaoPao(int a[6]){
    int n,i,j,min,t;
	n=6;
	for(i=1;i<n;i++){
		 
		for(j=0;j<6-i;j++){
			if(a[j]>a[j+1]){
				t=a[j+1];
				a[j+1]=a[j];
			    a[j]=t;			
			}
			 
		}
		
		 
	}
	for(i=0;i<n;i++){
	   printf("%d  ",a[i]);
	}
	printf("\n");
}