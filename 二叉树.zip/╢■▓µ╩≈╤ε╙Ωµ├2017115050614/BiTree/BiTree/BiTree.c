#include <stdio.h>
#include <stdlib.h>
#include "BiTree.h"
void CreatBiTree(BiTree *root){
	char ch;
	scanf("%c",&ch);
	//ǰ�����ɶ�����
	if(ch!='^'){
		*root=(BiTree)malloc(sizeof(BiTNode));
		(*root)->data=ch;
		CreatBiTree(&(*root)->leftChild);
		CreatBiTree(&(*root)->rightChild);
		
	}
	else{
		*root=NULL;
	
	}
}
static void visit(BiTree root,int real){
	
	printf("%c �ڵ�%d��\n",root->data,real);
}

//ǰ�����������
void TraversBiTree(BiTree root,int real){
	if(root){
	visit(root,real);
	TraversBiTree(root->leftChild,real+1);
	TraversBiTree(root->rightChild,real+1);
	}
	
}

void DestoryBiTree(BiTree root){
	if(root){
		DestoryBiTree(root->leftChild);
		DestoryBiTree(root->rightChild);
		free(root);
		root=NULL;
	}

}