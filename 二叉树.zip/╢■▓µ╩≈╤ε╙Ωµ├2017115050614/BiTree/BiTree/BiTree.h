typedef struct BiTNode{
	char data;
	struct BiTNode* leftChild;
	struct BiTNode* rightChild;

}BiTNode,*BiTree;
 void CreatBiTree(BiTree *root);
 void TraversBiTree(BiTree root,int real);
 void DestoryBiTree(BiTree root);